from setuptools import setup, find_packages

setup(name='requires_simple',
      version='0.1',
      install_requires=['simple==1.0']
      )
